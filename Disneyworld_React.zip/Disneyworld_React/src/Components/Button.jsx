

const Button= (props)=>{
    return (

        
        <>
        <button>{props.brand}</button>
        </>
    )
}

export default Button