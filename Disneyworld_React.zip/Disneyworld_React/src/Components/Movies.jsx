import MovieList from "./MovieList"
import disneylady from "../assets"

const Movies =()=>{


    const cartInfo = [
        <img  title= "disneylady"  src={"../../src/assets/disneylady.jpg"}  />
    ]
    return(

        <>
            <MovieList band = {cartInfo}/>
        
        </>
    )
}
export default Movies